# 修改MOTO Z²的U-Touch按键设置

ZUI还好 ，能设置按键功能，海外版就很蛋疼了

还好有[MYLF写的这篇教程](https://bbs.ixmoe.com/thread-2399-1-1.html)

而我姑且做了这个最简易的Magisk实现
